package com.mycompany.restauranteelbuensabor;

public class Imprimir {

    public static void mostrarCarta() {
        System.out.println("========================================");
        System.out.println("    RESTAURANTE EL BUEN SABOR");
        System.out.println("    --- NUESTRA CARTA ---");
        System.out.println("========================================");
        int i = 0;
        while (i < Datos.nombreProductos.length) {
            System.out.printf("%d. %-22s $%,.0f%n", (i + 1), Datos.nombreProductos[i], Datos.precioProductos[i]);
            i++;
        }// fin while
        System.out.println("========================================");
    }

    public static void mostrarPedido() {
        double sub = 0;
        int i = 0;
        System.out.println("--- PEDIDO ACTUAL ---");
        while (i < Datos.nombreProductos.length) {
            if (Datos.cantidadPedida[i] > 0) {
                System.out.printf("%-20s x%-6d $%,.0f%n", Datos.nombreProductos[i], Datos.cantidadPedida[i], (Datos.precioProductos[i] * Datos.cantidadPedida[i]));
                sub = sub + Datos.precioProductos[i] * Datos.cantidadPedida[i];
            }
            i++;
        }
        System.out.println("--------------------");
        System.out.printf("%-27s $%,.0f%n", "Subtotal:", sub);
    }

    public static void imprimirFacturaCompleta() {
        double sub = 0;
        double iva = 0;
        double tot = 0;
        double prop = 0;
        int cont = 0;
        double aux = 0;
        int i = 0;
        while (i < Datos.nombreProductos.length) {
            if (Datos.cantidadPedida[i] > 0) {
                sub = sub + Datos.precioProductos[i] * Datos.cantidadPedida[i];
                cont = cont + 1;
            }
            i++;
        }
        if (cont > 3) {
            aux = sub - (sub * 0.05);
        } else {
            aux = sub;
        }
        if (aux > 50000) {
            iva = aux * 0.19;
            tot = aux + iva;
            prop = tot * 0.10;
            tot = tot + prop;
        } else {
            iva = aux * 0.19;
            tot = aux + iva;
            prop = 0;
        }
        String sep = "========================================";
        System.out.println(sep);
        System.out.println("    RESTAURANTE EL BUEN SABOR");
        System.out.println("    Calle 15 #8-32, Valledupar");
        System.out.println("    NIT: 900.123.456-7");
        System.out.println(sep);
        System.out.printf("FACTURA No. %03d%n", Datos.numeroFactura);
        System.out.println("----------------------------------------");
// imprime cada item del pedido
        int j = 0;
        while (j < Datos.nombreProductos.length) {
            if (Datos.cantidadPedida[j] > 0) {
                System.out.printf("%-20s x%-6d $%,.0f%n", Datos.nombreProductos[j], Datos.cantidadPedida[j], (Datos.precioProductos[j] * Datos.cantidadPedida[j]));
            }
            j++;
        }
        System.out.println("----------------------------------------");
        System.out.printf("%-27s $%,.0f%n", "Subtotal:", aux);
        System.out.printf("%-27s $%,.0f%n", "IVA (19%):", iva);
        if (prop > 0) {
            System.out.printf("%-27s $%,.0f%n", "Propina (10%):", prop);
        }// fin if prop
        System.out.println("----------------------------------------");
        System.out.printf("%-27s $%,.0f%n", "TOTAL:", tot);
        System.out.println(sep);
        System.out.println("Gracias por su visita!");
        System.out.println("El Buen Sabor - Valledupar");
        System.out.println(sep);
// actualiza estado e incrementa factura - tres responsabilidades en un metodo
        Datos.numeroFactura = Datos.numeroFactura + 1;
        Datos.estadoMesa = 0;
        Datos.totalFactura = tot;
    }

    public static void imprimirFacturaResumen() {
        double sub = 0;
        double iva = 0;
        double tot = 0;
        double prop = 0;
        int cont = 0;
        double aux = 0;
        int i = 0;
        while (i < Datos.nombreProductos.length) {
            if (Datos.cantidadPedida[i] > 0) {
                sub = sub + Datos.precioProductos[i] * Datos.cantidadPedida[i];
                cont = cont + 1;
            }
            i++;
        }
        if (cont > 3) {
            aux = sub - (sub * 0.05);
        } else {
            aux = sub;
        }
        if (aux > 50000) {
            iva = aux * 0.19;
            tot = aux + iva;
            prop = tot * 0.10;
            tot = tot + prop;
        } else {
            iva = aux * 0.19;
            tot = aux + iva;
            prop = 0;
        }
        String sep = "========================================";
        System.out.println(sep);
        System.out.println("    RESTAURANTE EL BUEN SABOR");
        System.out.println("    Calle 15 #8-32, Valledupar");
        System.out.println("    NIT: 900.123.456-7");
        System.out.println(sep);
        System.out.printf("FACTURA No. %03d (RESUMEN)%n", Datos.numeroFactura);
        System.out.println("----------------------------------------");
        System.out.printf("%-27s $%,.0f%n", "Subtotal:", aux);
        System.out.printf("%-27s $%,.0f%n", "IVA (19%):", iva);
        if (prop > 0) {
            System.out.printf("%-27s $%,.0f%n", "Propina (10%):", prop);
        }
        System.out.println("----------------------------------------");
        System.out.printf("%-27s $%,.0f%n", "TOTAL:", tot);
        System.out.println(sep);
    }
}
